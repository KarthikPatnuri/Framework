package com.pageobjectmodel;

import org.testng.annotations.Test;

import com.uistorepack.TestCaseClass;
import com.utilitypac.Base;

public class HomeClass extends Base
{
	
	@Test
	public void exp()
	{		
		log=report.createTest("Aashirwad Page");
		
		log.info("Aashirwad website is running");
		TestCaseClass c=new TestCaseClass(driver);
		c.Popup().click();
		c.Dropdown().click();
		c.aata().click();
		c.aata().getText();
		c.instant().click();
		c.instant().getText();
		c.Privacy().click();
		c.Privacy().getText();
		//c.AbouttheBBC().click();	
		log.info("Aashirwad website is successfully loaded");
	}
}
