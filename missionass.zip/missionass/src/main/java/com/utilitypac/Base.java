package com.utilitypac;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.resuable.DriverClass;
import com.resuable.Helper;


public class Base
{
	public WebDriver driver;
	public ConfigureClass con;
	
	public ExtentReports report;
	public ExtentTest log;
	
	@BeforeSuite
	public void setUp() throws Exception
	{
		con= new ConfigureClass();
		ExtentSparkReporter extent = new ExtentSparkReporter(new File(System.getProperty("user.dir")+"/reports/"+Helper.getCurrentDateTime()+".html"));
		report = new ExtentReports();
		report.attachReporter(extent);
	}
	
	@BeforeClass
	public void welcome()
	{
		driver=DriverClass.launch(driver, con.getBrowser(), con.getURL());
	}
	
	@AfterClass
	public void bye()
	{
		DriverClass.quit(driver);
	}
	
	@AfterMethod
	public void ssMethod(ITestResult result) throws Exception
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			//HelperClass.screenShot(driver);
			log.fail("Test Failed", MediaEntityBuilder.createScreenCaptureFromPath(Helper.screenShot(driver)).build());
			log.fail("Oops! The testcase failed");
		}
		else if(result.getStatus()==ITestResult.SUCCESS)
		{
			log.pass("The Screenshot is updating of successfull testcase");
			log.pass("Test Passed", MediaEntityBuilder.createScreenCaptureFromPath(Helper.screenShot(driver)).build());
			log.pass("The Screenshot is updated of successfull testcase");
		}
		report.flush();
	}
	

}
