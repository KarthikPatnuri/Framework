package com.uistorepack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TestCaseClass
{
	WebDriver driver;
	
	public TestCaseClass(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="//div[@id='tbp_pop2']//descendant::button[@data-dismiss='modal']") WebElement close;
	@FindBy(xpath="//*[@id='navbarDropdown']")WebElement dropdown;
	@FindBy(linkText="AASHIRVAAD  Select Atta")WebElement dropdown1;
	@FindBy(linkText="AASHIRVAAD  Instant Mixes")WebElement dropdown2;
	@FindBy(linkText="Privacy Policy")WebElement pp;
	
	
	public WebElement Popup()
	{
		return close;
	
	}
	public WebElement Dropdown()
	{
		return dropdown;
	}
	public WebElement aata()
	{
		return dropdown1;
	}
	
	public WebElement instant()
	{
		return dropdown2;
	}
	public WebElement Privacy()
	{
		return pp;
	}
	
}
